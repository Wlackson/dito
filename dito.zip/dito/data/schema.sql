--
-- Table structure for table `navinfo`
--

CREATE TABLE `navinfo` (
  `id` char(36) NOT NULL,
  `userid` char(36) NOT NULL,
  `event` char(20) NOT NULL,
  `agent` varchar(255) NULL,
  `host` varchar(255) NOT NULL,
  `referer` varchar(255) NULL,
  `language` char(5) NULL,
  `screenwidth` char(5) NULL,
  `screenheight` char(5) NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores users browsing info';

