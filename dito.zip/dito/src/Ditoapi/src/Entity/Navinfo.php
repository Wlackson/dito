<?php

declare(strict_types=1);

namespace Ditoapi\Entity;

use Doctrine\ORM\Mapping as ORM;
use Ramsey\Uuid\Uuid;

/**
* https://www.doctrine-project.org/projects/doctrine-orm/en/2.6/reference/basic-mapping.html
*
* @ORM\Entity
* @ORM\Table(name="navinfo")
**/
class Navinfo
{
    /**
     * @var Uuid
     *
     * @ORM\Id
     * @ORM\Column(type="uuid", unique=true)
     * @ORM\GeneratedValue(strategy="CUSTOM")
     * @ORM\CustomIdGenerator(class="Ramsey\Uuid\Doctrine\UuidGenerator")
     */
    protected $id;

    /**
    * @ORM\Column(type="string", nullable=false)
    */
    protected $userid;

    /**
    * @ORM\Column(type="string", nullable=false)
    */
    protected $event;

    /**
    * @ORM\Column(type="string", nullable=true)
    */
    protected $agent;

    /**
     * @ORM\Column(type="string", nullable=true)
     */
    protected $host;

    /**
     * @ORM\Column(type="string", nullable=true)
     */
    protected $referer;

    /**
     * @ORM\Column(type="string", nullable=true)
     */
    protected $language;

    /**
     * @ORM\Column(type="string", nullable=true)
     */
    protected $screenwidth;

    /**
     * @ORM\Column(type="string", nullable=true)
     */
    protected $screenheight;

    /**
    * @ORM\Column(type="datetime", nullable=false)
    */
    protected $created;

    /**
     * @ORM\Column(type="string", nullable=true)
     */
    protected $ip;

    /**
    *
    * @return array|mixed
    */
    public function getEvents(): array
    {
        return
                [
                    'id' => $this->getId(),
                    'userid' => $this->getUserid(),
                    'event' => $this->getEvent(),
                    'agent' => $this->getAgent(),
                    'host' => $this->getHost(),
                    'referer' => $this->getReferer(),
                    'language' => $this->getLanguage(),
                    'screenwidth' => $this->getScreenwidth(),
                    'screenheight' => $this->getScreenheight(),
                    'created' => $this->getCreated()->format('Y-m-d H:i:s'),
                    'ip' => $this->getIp(),
                ];
    }

    /**
     * @param array $requestBody
     * @throws \Exception
     */
    public function setEvents(array $requestBody): void
    {
        $this->setUserid($requestBody['userid']);
        $this->setEvent($requestBody['event']);
        $this->setAgent($requestBody['agent']);
        $this->setHost($requestBody['host']);
        $this->setReferer($requestBody['referer']);
        $this->setLanguage($requestBody['language']);
        $this->setScreenwidth($requestBody['screenwidth']);
        $this->setScreenheight($requestBody['screenheight']);
        $this->setIp($requestBody['ip']);
    }

    /**
    * @return Uuid
    */
    public function getId(): Uuid
    {
        return $this->id;
    }

    /**
    * @return string
    */
    public function getUserid(): string
    {
        return $this->userid;
    }

    /**
    * @param string $userid
    */
    public function setUserid(string $userid): void
    {
        $this->userid = $userid;
    }

    /**
     * @return string
     */
    public function getEvent(): string
    {
        return $this->event;
    }

    /**
     * @param string $event
     */
    public function setEvent(string $event): void
    {
        $this->event = $event;
    }


    /**
     * @return string
     */
    public function getAgent(): string
    {
        return $this->agent;
    }

    /**
     * @param string $agent
     */
    public function setAgent(string $agent): void
    {
        $this->agent = $agent;
    }

    /**
     * @return string
     */
    public function getHost(): string
    {
        return $this->host;
    }

    /**
     * @param string $host
     */
    public function setHost(string $host): void
    {
        $this->host = $host;
    }

    /**
     * @return string
     */
    public function getReferer(): string
    {
        return $this->referer;
    }

    /**
     * @param string $referer
     */
    public function setReferer(string $referer): void
    {
        $this->referer = $referer;
    }

    /**
     * @return string
     */
    public function getLanguage(): string
    {
        return $this->language;
    }

    /**
     * @param string $language
     */
    public function setLanguage(string $language): void
    {
        $this->language = $language;
    }

    /**
     * @return string
     */
    public function getScreenwidth(): string
    {
        return $this->screenwidth;
    }

    /**
     * @param string $screenwidth
     */
    public function setScreenwidth(string $screenwidth): void
    {
        $this->screenwidth = $screenwidth;
    }

    /**
     * @return string
     */
    public function getScreenheight(): string
    {
        return $this->screenheight;
    }

    /**
     * @param string $screenheight
     */
    public function setScreenheight(string $screenheight): void
    {
        $this->screenheight = $screenheight;
    }

    /**
    * @return \DateTime
    */
    public function getCreated(): \DateTime
    {
        return $this->created;
    }

    /**
    * @param \DateTime $created
    * @throws \Exception
    */
    public function setCreated(\DateTime $created = null): void
    {
        if (!$created && empty($this->getId())) {
            $this->created = new \DateTime("now");
        } else {
            $this->created = $created;
        }
    }

    /**
     * @return string
     */
    public function getIp(): string
    {
        return $this->ip;
    }

    /**
     * @param string $ip
     */
    public function setIp(string $ip): void
    {
        $this->ip = $ip;
    }
}
