<?php

declare(strict_types=1);

namespace Ditoapi\Entity;


use Doctrine\ORM\Tools\Pagination\Paginator;

class NavinfoCollection extends Paginator
{

}