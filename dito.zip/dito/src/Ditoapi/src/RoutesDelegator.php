<?php

namespace Ditoapi;

use Psr\Container\ContainerInterface;
use Zend\Expressive\Application;

class RoutesDelegator
{
    /**
     * @param ContainerInterface $container
     * @param string $serviceName Name of the service being created.
     * @param callable $callback Creates and returns the service.
     * @return Application
     */
    public function __invoke(ContainerInterface $container, $serviceName, callable $callback)
    {
        /** @var $app Application */
        $app = $callback();

        // Setup routes

        $app->post('/ditoapi/v1/events[/]', Handler\DitoapiCreateHandler::class, 'ditoapi.create');

        $app->get('/ditoapi/v1/events/find/{id:[0-9A-Fa-f]{8}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{12}}[/]', Handler\DitoapiReadHandler::class, 'ditoapi.read');

        $app->get('/ditoapi/v1/events/[?page=/{page:\d+}]', Handler\DitoapiListHandler::class, 'ditoapi.list');

        $app->get('/ditoapi/v1/events/autocomplete/{event:[a-zA-Z0-9-]+}[/]', Handler\DitoapiAutocompleteHandler::class, 'ditoapi.autocomplete');

        $app->get('/ditoapi/v1/events/data[/]', Handler\DitoapiDataManipulationHandler::class, 'ditoapi.data');

//      $app->put('/ditoapi/v1/events/{id:[0-9A-Fa-f]{8}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{12}}[/]', Handler\DitoapiUpdateHandler::class, 'ditoapi.update');

//      $app->delete('/ditoapi/v1/events/{id:[0-9A-Fa-f]{8}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{12}}[/]', Handler\DitoapiDeleteHandler::class, 'ditoapi.delete');

        return $app;
    }
}
