<?php

declare(strict_types=1);

namespace Ditoapi\Handler;

use Ditoapi\Entity\Navinfo;
use Doctrine\ORM\EntityManager;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use Psr\Http\Server\RequestHandlerInterface;
use Zend\Diactoros\Response\JsonResponse;
use Zend\Expressive\Hal\HalResponseFactory;
use Zend\Expressive\Hal\ResourceGenerator;

class DitoapiAutocompleteHandler implements RequestHandlerInterface
{
    protected $entityManager;
    protected $resourceGenerator;
    protected $halResponseFactory ;

    public function __construct(
        EntityManager $entityManager,
        ResourceGenerator $resourceGenerator,
        HalResponseFactory $halResponseFactory
    ) {
        $this->entityManager = $entityManager;
        $this->resourceGenerator = $resourceGenerator;
        $this->halResponseFactory  = $halResponseFactory ;
    }

    public function handle(ServerRequestInterface $request) : ResponseInterface
    {
        $event = $request->getAttribute('event', null);

        if ((strlen($event) > 1) && (strlen($event) < 20)) {
            $query = $this->entityManager->createQueryBuilder();
            $query
                ->addSelect('e.event')
                ->from(Navinfo::class, 'e')
                ->setMaxResults(10)
                ->where('e.event LIKE ?1')
                ->setParameter('1', '%' . $event . '%');

            $result = $query->getQuery()->getResult();

            if (!empty($result)) {
                return new JsonResponse($result);
            }
        }
        return new JsonResponse([]);
    }
}
