<?php

declare(strict_types=1);

namespace Ditoapi\Handler;

use Ditoapi\Entity\Announcement;
use Ditoapi\Entity\Navinfo;
use Doctrine\ORM\EntityManager;
use Doctrine\ORM\ORMException;
use function PHPSTORM_META\elementType;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use Psr\Http\Server\RequestHandlerInterface;
use Zend\Diactoros\Response\JsonResponse;
use Zend\Expressive\Hal\HalResponseFactory;
use Zend\Expressive\Hal\ResourceGenerator;

class DitoapiCreateHandler implements RequestHandlerInterface
{

    protected $entityManager;
    protected $resourceGenerator;
    protected $halResponseFactory ;

    public function __construct(
        EntityManager $entityManager,
        ResourceGenerator $resourceGenerator,
        HalResponseFactory $halResponseFactory
    ) {
        $this->entityManager = $entityManager;
        $this->resourceGenerator = $resourceGenerator;
        $this->halResponseFactory  = $halResponseFactory ;
    }

    public function handle(ServerRequestInterface $request) : ResponseInterface
    {
        $requestBody = $request->getParsedBody()['Request']['Navinfo'];

        if (empty($requestBody)) {
            $result['_error']['error'] = 'missing_request';
            $result['_error']['error_description'] = 'No request body sent.';

            return new JsonResponse($result, 400);
        }

        $entity = new Navinfo();

        try {
            $entity->setEvents($requestBody);

            if ($this->validateDate($requestBody['created'], 'Y-m-d\TH:i:sP') == true) {
                $entity->setCreated(new \DateTime($requestBody['created']));
            } else {
                $entity->setCreated(new \DateTime("now"));
            }

            $this->entityManager->persist($entity);
            $this->entityManager->flush();

        } catch (ORMException $e) {
            $result['_error']['error'] = 'not_created';
            $result['_error']['error_description'] = $e->getMessage();

            return new JsonResponse($result, 400);
        }

        $resource = $this->resourceGenerator->fromObject($entity, $request);

        return $this->halResponseFactory->createResponse($request, $resource);
    }

    public function validateDate($date, $format = 'Y-m-d H:i:s')
    {
        $d = \DateTime::createFromFormat($format, $date);
        return $d && $d->format($format) == $date;
    }
}
