<?php

declare(strict_types=1);

namespace Ditoapi\Handler;

use Doctrine\ORM\EntityManager;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use Psr\Http\Server\RequestHandlerInterface;
use Zend\Diactoros\Response\JsonResponse;
use Zend\Expressive\Hal\HalResponseFactory;
use Zend\Expressive\Hal\ResourceGenerator;

class DitoapiDataManipulationHandler implements RequestHandlerInterface
{
    protected $entityManager;
    protected $resourceGenerator;
    protected $halResponseFactory ;

    public function __construct(
        EntityManager $entityManager,
        ResourceGenerator $resourceGenerator,
        HalResponseFactory $halResponseFactory
    ) {
        $this->entityManager = $entityManager;
        $this->resourceGenerator = $resourceGenerator;
        $this->halResponseFactory  = $halResponseFactory ;
    }

    public function handle(ServerRequestInterface $request) : ResponseInterface
    {
        try {
            $json = file_get_contents('https://storage.googleapis.com/dito-questions/events.json');
            if ($json === false) {
                $error = ["Error" => "Remote source error"];
                return new JsonResponse($error, 400);
            }
        } catch (Exception $e) {
            $exception = ["Exception" => "Remote source nor found"];
            return new JsonResponse($exception, 400);
        }
        $obj = json_decode($json);
        $timeline['timeline'] = [];
        foreach ($obj->events as $key => $array) {
            $transactObject = array_filter(
                $obj->events[$key]->custom_data,
                function ($e) {
                    return $e->key == 'transaction_id';
                }
            );
            $transactId = $transactObject[key($transactObject)]->value;
            $timeEvent = array_filter(
                $timeline['timeline'],
                function ($e) use ($transactId) {
                    return $e->transaction_id == $transactId;
                }
            );
            if (empty($timeEvent)) {
                $timelineEvents = new \stdClass();
                if ($obj->events[$key]->event == "comprou") {
                    $storeObject = array_filter(
                        $obj->events[$key]->custom_data,
                        function ($e) {
                            return $e->key == 'store_name';
                        }
                    );
                    $storeName = $storeObject[key($storeObject)]->value;
                    $timelineEvents->timestamp = $obj->events[$key]->timestamp;
                    $timelineEvents->revenue = $obj->events[$key]->revenue;
                    $timelineEvents->transaction_id = $transactId;
                    $timelineEvents->store_name = $storeName;
                } else {
                    $productName = array_filter(
                        $obj->events[$key]->custom_data,
                        function ($e) {
                            return $e->key == 'product_name';
                        }
                    );
                    $productName = $productName[key($productName)]->value;
                    $productPrice = array_filter(
                        $obj->events[$key]->custom_data,
                        function ($e) {
                            return $e->key == 'product_price';
                        }
                    );
                    $productPrice = $productPrice[key($productPrice)]->value;
                    $timelineEvents->timestamp = "";
                    $timelineEvents->revenue = "";
                    $timelineEvents->transaction_id = $transactId;
                    $timelineEvents->store_name = "";
                    $timelineEvents->products[] = ["name" => $productName, "price" => $productPrice];
                }
                $timeline['timeline'][] = $timelineEvents;
            } else {
                $eventKey = key($timeEvent);
                if ($obj->events[$key]->event == "comprou") {
                    $storeObject = array_filter(
                        $obj->events[$key]->custom_data,
                        function ($e) {
                            return $e->key == 'store_name';
                        }
                    );
                    $storeName = $storeObject[key($storeObject)]->value;
                    $timeline['timeline'][$eventKey]->timestamp = $obj->events[$key]->timestamp;
                    $timeline['timeline'][$eventKey]->revenue = $obj->events[$key]->revenue;
                    $timeline['timeline'][$eventKey]->transaction_id = $transactId;
                    $timeline['timeline'][$eventKey]->store_name = $storeName;
                } else {
                    $productName = array_filter(
                        $obj->events[$key]->custom_data,
                        function ($e) {
                            return $e->key == 'product_name';
                        }
                    );
                    $productName = $productName[key($productName)]->value;
                    $productPrice = array_filter(
                        $obj->events[$key]->custom_data,
                        function ($e) {
                            return $e->key == 'product_price';
                        }
                    );
                    $productPrice = $productPrice[key($productPrice)]->value;
                    $timeline['timeline'][$eventKey]->products[] = ["name" => $productName, "price" => $productPrice];
                }
            }
        }
        usort($timeline['timeline'], [$this, "compareTabAndOrder"]);
        return new JsonResponse($timeline);
    }

    public function compareTabAndOrder($a, $b)
    {
        $diff = strtotime($b->timestamp) - strtotime($a->timestamp);
        if ($diff !== 0) {
            return $diff;
        }
    }
}
