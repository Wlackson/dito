<?php

declare(strict_types=1);

namespace Ditoapi\Handler;

use Ditoapi\Entity\Navinfo;
use Doctrine\ORM\EntityManager;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use Psr\Http\Server\RequestHandlerInterface;
use Zend\Diactoros\Response\JsonResponse;
use Zend\Expressive\Hal\HalResponseFactory;
use Zend\Expressive\Hal\ResourceGenerator;

class DitoapiReadHandler implements RequestHandlerInterface
{
    protected $entityManager;
    protected $resourceGenerator;
    protected $halResponseFactory;

    public function __construct(
        EntityManager $entityManager,
        ResourceGenerator $resourceGenerator,
        HalResponseFactory $halResponseFactory
    ) {
        $this->entityManager = $entityManager;
        $this->resourceGenerator = $resourceGenerator;
        $this->halResponseFactory = $halResponseFactory;
    }

    public function handle(ServerRequestInterface $request) : ResponseInterface
    {
        $id = $request->getAttribute('id', null);
        $entityRepository = $this->entityManager->getRepository(Navinfo::class);
        $entity = $entityRepository->find($id);

        if (empty($entity)) {
            $result['_error']['error'] = 'not found';
            $result['_error']['error_description'] = 'Record not found.';

            return new JsonResponse($result, 404);
        }

        $resource = $this->resourceGenerator->fromObject($entity, $request);

        return $this->halResponseFactory->createResponse($request, $resource);
    }
}
