<?php

declare(strict_types=1);

namespace Ditoapi;

use Ditoapi\Entity\Navinfo;
use Ditoapi\Entity\NavinfoCollection;
use Doctrine\Common\Persistence\Mapping\Driver\MappingDriverChain;
use Doctrine\ORM\Mapping\Driver\AnnotationDriver;
use Zend\Expressive\Hal\Metadata\MetadataMap;
use Zend\Expressive\Hal\Metadata\RouteBasedCollectionMetadata;
use Zend\Expressive\Hal\Metadata\RouteBasedResourceMetadata;
use Zend\Hydrator\ReflectionHydrator;

/**
 * The configuration provider for the Ditoapi module
 *
 * @see https://docs.zendframework.com/zend-component-installer/
 */
class ConfigProvider
{
    /**
     * Returns the configuration array
     *
     * To add a bit of a structure, each section is defined in a separate
     * method which returns an array with its configuration.
     */
    public function __invoke() : array
    {
        return [
            'dependencies' => $this->getDependencies(),
            'templates'    => $this->getTemplates(),
            'doctrine'     => $this->getDoctrineEntities(),
            MetadataMap::class => $this->getHalMetadataMap(),

        ];
    }

    /**
     * Returns the container dependencies
     */
    public function getDependencies() : array
    {
        return [
            'delegators' => [
                \Zend\Expressive\Application::class => [
                    RoutesDelegator::class,
                ],
            ],
            'invokables' => [
            ],
            'factories'  => [
                Handler\DitoapiListHandler::class => Handler\DitoapiListHandlerFactory::class,
                Handler\DitoapiReadHandler::class => Handler\DitoapiReadHandlerFactory::class,
                Handler\DitoapiCreateHandler::class => Handler\DitoapiCreateHandlerFactory::class,
                Handler\DitoapiUpdateHandler::class => Handler\DitoapiUpdateHandlerFactory::class,
                Handler\DitoapiDeleteHandler::class => Handler\DitoapiDeleteHandlerFactory::class,
                Handler\DitoapiAutocompleteHandler::class => Handler\DitoapiAutocompleteHandlerFactory::class,
                Handler\DitoapiDataManipulationHandler::class => Handler\DitoapiDataManipulationHandlerFactory::class,
            ],
        ];
    }

    /**
     * Returns the templates configuration
     */
    public function getTemplates() : array
    {
        return [
            'paths' => [
                'ditoapi'    => [__DIR__ . '/../templates/'],
            ],
        ];
    }

    public function getDoctrineEntities() : array
    {
        return [
            'driver' => [
                'orm_default' => [
                    'class' => MappingDriverChain::class,
                    'drivers' => [
                        'Ditoapi\Entity' => 'dito_entity',
                    ],
                ],
                'dito_entity' => [
                    'class' => AnnotationDriver::class,
                    'cache' => 'array',
                    'paths' => [__DIR__ . '/Entity'],
                ],
            ],
        ];
    }

    public function getHalMetadataMap()
    {
        return [
            [
                '__class__' => RouteBasedResourceMetadata::class,
                'resource_class' => Navinfo::class,
                'route' => 'ditoapi.read',
                'extractor' => ReflectionHydrator::class,
            ],
            [
                '__class__' => RouteBasedCollectionMetadata::class,
                'collection_class' => NavinfoCollection::class,
                'collection_relation' => 'navinfo',
                'route' => 'ditoapi.list',
            ],
        ];
    }
}
